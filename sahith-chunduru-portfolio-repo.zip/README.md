# Sahith Chunduru — Personal Portfolio Website

Portfolio repository for **Sahith Chunduru**, highlighting background in **Product Engineering with AI (PEWAI)** at SRM University-AP and **Data Science & Applications** at IIT Madras.

## 🚀 Live Projects Featured
- **SynDoc 2.0 (Real-Time Collaborative Document Editor):** [https://syndoc-creative-hub.vercel.app/](https://syndoc-creative-hub.vercel.app/)
  - Concurrent multi-user editing, live cursors, presence awareness, and CRDT-based synchronization with Yjs.
- **SyncDoc Prototype (Offline-First Collaborative Editor):** [https://collab-doc-editor-silk.vercel.app/](https://collab-doc-editor-silk.vercel.app/)
  - Experimental editor handling network latency, offline persistence via IndexedDB, and automatic reconnection merging.

## 🛠️ Tech Stack
- **HTML5 & Modern JavaScript (ES6+)**
- **Tailwind CSS (CDN)**
- **Lucide Icons**
- **Responsive Dark Mode UI**

## 💻 Quick Start / Local Setup
Simply open `index.html` in any modern web browser, or serve it with:
```bash
npx serve .
```

## 🌐 Deploy to GitHub Pages
1. Push this folder to a GitHub repository named `portfolio` (or `<your-username>.github.io`).
2. Go to **Settings > Pages**.
3. Under **Branch**, select `main` and `/ (root)`, then click **Save**.
4. Your site will be online in ~1 minute!

## 📬 Contact
- **Email:** Sahithchunduru@gmail.com
- **Phone:** +91 8466862008
- **GitHub:** [github.com/Sahith1780](https://github.com/Sahith1780)
- **LinkedIn:** [linkedin.com/in/Sahith4248](https://www.linkedin.com/in/Sahith4248)
